package reit;

import java.util.concurrent.Callable;

public class CallableSimulateStayInAsset implements Callable<Double> {

	@Override
	public Object call() throws Exception {
		// TODO Auto-generated method stub
		wait();
		return null;
	}

}
